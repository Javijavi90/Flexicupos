<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../session.php';

Session::start();
if (!Session::has('user_id') || Session::get('user_rol') !== 'prestador') {
    echo json_encode(['status' => 'error', 'message' => 'No autorizado']);
    exit;
}

$userId = Session::get('user_id');
$method = $_SERVER['REQUEST_METHOD'];

try {
    $db = Database::getConnection();

    // Obtener perfil del prestador
    if ($method === 'GET') {
        $stmt = $db->prepare("
            SELECT u.nombre, u.correo, u.telefono,
                   p.id as perfil_id, p.tipo_entidad, p.nombre_legal, p.apellido_legal,
                   p.nombre_empresa, p.ruc, p.especialidad, p.categoria,
                   p.direccion_fisica, p.descripcion, p.sitio_web, p.redes_sociales,
                   p.logo_url, p.activo_etiqueta
            FROM usuarios u
            JOIN perfiles_prestadores p ON u.id = p.usuario_id
            WHERE u.id = :id
        ");
        $stmt->execute(['id' => $userId]);
        $data = $stmt->fetch();

        // Obtener servicios con planes
        $stmtServ = $db->prepare("SELECT * FROM servicios_precios WHERE prestador_id = (SELECT id FROM perfiles_prestadores WHERE usuario_id = :uid) ORDER BY creado_en");
        $stmtServ->execute(['uid' => $userId]);
        $servicios = $stmtServ->fetchAll();

        foreach ($servicios as &$serv) {
            $stmtPlanes = $db->prepare("SELECT * FROM planes_servicio WHERE servicio_id = :sid ORDER BY precio");
            $stmtPlanes->execute(['sid' => $serv['id']]);
            $serv['planes'] = $stmtPlanes->fetchAll();
        }

        // Obtener imágenes
        $stmtImg = $db->prepare("SELECT * FROM imagenes_portafolio WHERE prestador_id = (SELECT id FROM perfiles_prestadores WHERE usuario_id = :uid) ORDER BY subido_en DESC");
        $stmtImg->execute(['uid' => $userId]);
        $imagenes = $stmtImg->fetchAll();

        echo json_encode([
            'status' => 'success',
            'data' => $data,
            'servicios' => $servicios,
            'imagenes' => $imagenes
        ]);
        exit;
    }

    // Actualizar perfil
    if ($method === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);

        $tipoEntidad = $input['tipo_entidad'] ?? 'particular';
        $nombreLegal = $input['nombre_legal'] ?? '';
        $apellidoLegal = $input['apellido_legal'] ?? '';
        $nombreEmpresa = $input['nombre_empresa'] ?? '';
        $ruc = $input['ruc'] ?? '';
        $especialidad = trim($input['especialidad'] ?? '');
        $categoria = trim($input['categoria'] ?? '');
        $direccion = trim($input['direccion_fisica'] ?? '');
        $descripcion = trim($input['descripcion'] ?? '');
        $sitioWeb = trim($input['sitio_web'] ?? '');
        $redesSociales = trim($input['redes_sociales'] ?? '');
        $nombre = trim($input['nombre'] ?? '');
        $telefono = trim($input['telefono'] ?? '');

        if (empty($especialidad) || empty($direccion)) {
            echo json_encode(['status' => 'error', 'message' => 'Especialidad y dirección son obligatorios.']);
            exit;
        }

        $db->beginTransaction();

        // Actualizar datos de usuario
        $stmtUser = $db->prepare("UPDATE usuarios SET nombre = :nombre, telefono = :telefono WHERE id = :id");
        $stmtUser->execute(['nombre' => $nombre, 'telefono' => $telefono, 'id' => $userId]);

        // Actualizar perfil del prestador
        $stmtPerfil = $db->prepare("
            UPDATE perfiles_prestadores SET
                tipo_entidad = :tipo_entidad,
                nombre_legal = :nombre_legal,
                apellido_legal = :apellido_legal,
                nombre_empresa = :nombre_empresa,
                ruc = :ruc,
                especialidad = :especialidad,
                categoria = :categoria,
                direccion_fisica = :direccion,
                descripcion = :descripcion,
                sitio_web = :sitio_web,
                redes_sociales = :redes_sociales
            WHERE usuario_id = :uid
        ");
        $stmtPerfil->execute([
            'tipo_entidad' => $tipoEntidad,
            'nombre_legal' => $nombreLegal,
            'apellido_legal' => $apellidoLegal,
            'nombre_empresa' => $nombreEmpresa,
            'ruc' => $ruc,
            'especialidad' => $especialidad,
            'categoria' => $categoria,
            'direccion' => $direccion,
            'descripcion' => $descripcion,
            'sitio_web' => $sitioWeb,
            'redes_sociales' => $redesSociales,
            'uid' => $userId
        ]);

        $db->commit();

        echo json_encode(['status' => 'success', 'message' => 'Perfil actualizado correctamente.']);
        exit;
    }

    echo json_encode(['status' => 'error', 'message' => 'Método no permitido.']);

} catch (Exception $e) {
    if (isset($db) && $db->inTransaction()) $db->rollBack();
    error_log(date('[Y-m-d H:i:s] ') . "API Prestador Perfil Error: " . $e->getMessage() . "\n", 3, __DIR__ . '/../../logs/errores.log');
    echo json_encode(['status' => 'error', 'message' => 'Error interno del servidor.']);
}
